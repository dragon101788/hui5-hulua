result = cpp_func(1, 2)

print("cpp_func(1,2) = "..result)


function lua_func(arg1, arg2)
	return arg1 + arg2
end



